import java.text.ParseException;
import java.util.List;
import java.util.Scanner;

import dao.AdminAuthenticator;
import dao.AdminMovieDao;
import dao.Authenticator;
import dao.CustomerAuthenticator;
import dao.CustomerMovieDao;
import model.Customer;
import model.Movie;
import model.User;
import util.DateUtil;

public class Main {
	private static final Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		int ch;
		do {
			System.out.println("1. Login as Admin\n2. Login as Customer\nAny other number to exit");
			ch = sc.nextInt();
			sc.nextLine();
			switch (ch) {
			case 1:
				adminTest();
				break;
			case 2:
				customerTest();
			}

		} while (ch == 1 || ch == 2);
	}

	public static void adminTest() {
		System.out.print("Enter admin Username : ");
		String userName = sc.nextLine();
		System.out.print("Enter admin Password : ");
		String password = sc.nextLine();
		Authenticator adminAuthenticator = new AdminAuthenticator();
		User currentAdmin = adminAuthenticator.authenticate(userName, password);
		if (currentAdmin != null) {
			AdminMovieDao adminMovieDao = new AdminMovieDao();
			int ch;
			do {
				System.out.println(
						"1. View Movies List.\n2. Add Movie to list.\n3. Remove Movie from list.\n4. Edit a Movie\n5. Return to main menu / Logout.");
				System.out.print("Enter your choice : ");
				ch = sc.nextInt();
				sc.nextLine();
				switch (ch) {
				case 1:
					List<Movie> movies = adminMovieDao.getMoviesList();
					System.out.printf("%20s\t%10s\t%s\t%10s\t%15s\t%s\n", "Title", "Box Office", "Active",
							"Date of Launch", "Genre", "Has Teaser");
					for (Movie movie : movies)
						System.out.println(movie);
					break;
				case 2:
					System.out.println("Enter Movie details separated by ',' : ");
					String[] movieDetails = sc.nextLine().split(",");
					try {
						Movie movie = new Movie(movieDetails[0], Long.valueOf(movieDetails[1]),
								Boolean.valueOf(movieDetails[2]), DateUtil.convertToDate(movieDetails[3]),
								movieDetails[4], Boolean.valueOf(movieDetails[5]));
						adminMovieDao.addMovie(movie);
						System.out.println("Movie Added Successfully");
					} catch (NumberFormatException e) {
						e.printStackTrace();
					} catch (ParseException e) {
						e.printStackTrace();
					}
					break;
				case 3:
					System.out.print("Enter Movie title : ");
					String title = sc.nextLine();
					if (adminMovieDao.removeMovie(title)) {
						System.out.println("Movie Remove successfully");
					} else {
						System.out.println("Movie Does not exist");
					}
					break;
				case 4:
					System.out.println("Enter Movie title to edit : ");
					title = sc.nextLine();
					Movie movieToEdit = adminMovieDao.getMovie(title);
					if (movieToEdit != null) {
						System.out.println("Enter Movie details separated by ',' : ");
						movieDetails = sc.nextLine().split(",");
						try {
							Movie movie = new Movie(movieDetails[0], Long.valueOf(movieDetails[1]),
									Boolean.valueOf(movieDetails[2]), DateUtil.convertToDate(movieDetails[3]),
									movieDetails[4], Boolean.valueOf(movieDetails[5]));
							adminMovieDao.updateMovie(movieToEdit.getTitle(),movie);
							System.out.println("Movie Updated Successfully");
						} catch (NumberFormatException e) {
							e.printStackTrace();
						} catch (ParseException e) {
							e.printStackTrace();
						}
					}
					break;
				case 5:
					return;
				default:
					System.out.println("Invalid Input");
				}
			} while (true);

		} else {
			System.out.println("Wrong user id or password");
		}
	}

	public static void customerTest() {
		System.out.print("Enter Customer username : ");
		String userName = sc.nextLine();
		System.out.print("Enter Customer password : ");
		String password = sc.nextLine();
		CustomerAuthenticator customerAuthenticator = new CustomerAuthenticator();
		Customer currentCustomer = customerAuthenticator.authenticate(userName, password);
		if (currentCustomer != null) {
			CustomerMovieDao customerMovieDao = new CustomerMovieDao();
			int ch;
			do {
				System.out.println(
						"1. View Movies List.\n2. View All Favourites\n3. Add Movie to favourites.\n4. Remove Movie from favourites.\n5. Return to main menu /  Logout.");
				ch = sc.nextInt();
				sc.nextLine();
				switch (ch) {
				case 1:
					List<Movie> movies = customerMovieDao.getAllMovies();
					System.out.printf("%20s\t%10s\t%15s\t%s\n", "Title", "Box Office", "Genre", "Has Teaser");
					for (Movie movie : movies) {
						System.out.printf("%20s\t%10s\t%15s\t%s\n", movie.getTitle(), movie.getBoxOffice(),
								movie.getGenre(), movie.getHasTeaser());
					}
					break;
				case 3:
					System.out.println("Enter Movie Title : ");
					String title = sc.nextLine();
					Movie currentMovie = customerMovieDao.getMovie(title);
					if(currentMovie != null){
						customerMovieDao.addToFavourites(currentCustomer.getUserName(), currentMovie);
					} else {
						System.out.println("Movie not found");
					}
					break;
				case 2:
					List<Movie> favourites = customerMovieDao.getAllFavourites(currentCustomer.getUserName());
					System.out.printf("%20s\t%10s\t%15s\t%s\n", "Title", "Box Office", "Genre", "Has Teaser");
					for (Movie movie : favourites) {
						System.out.printf("%20s\t%10s\t%15s\t%s\n", movie.getTitle(), movie.getBoxOffice(),
								movie.getGenre(), movie.getHasTeaser());
					}
					break;
				case 4:
					System.out.print("Enter Movie title to remove : ");
					title = sc.nextLine();
					
					if (customerMovieDao.removeFromFavourites(currentCustomer.getUserName(), title)){
						System.out.println("Movie Remove from favourites successfully");
					} else {
						System.out.println("Movie Does not exist");
					}
					break;
				case 5:
					return;
				default:
					System.out.println("Invalid Input");
				}
			} while (true);

		}
	}

}
