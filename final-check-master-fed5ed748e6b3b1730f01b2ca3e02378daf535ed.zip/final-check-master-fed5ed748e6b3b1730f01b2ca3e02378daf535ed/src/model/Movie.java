package model;

import java.util.Date;

import util.DateUtil;

public class Movie {
	private String title;
	private Long boxOffice;
	private Boolean active;
	private Date dateOfLaunch;
	private String genre;
	private Boolean hasTeaser;
	public Movie() {
	}
	public Movie(String title, Long boxOffice, Boolean active, Date dateOfLaunch, String genre,
			Boolean hasTeaser) {
		super();
		this.title = title;
		this.boxOffice = boxOffice;
		this.active = active;
		this.dateOfLaunch = dateOfLaunch;
		this.genre = genre;
		this.hasTeaser = hasTeaser;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Long getBoxOffice() {
		return boxOffice;
	}
	public void setBoxOffice(Long boxOffice) {
		this.boxOffice = boxOffice;
	}
	public Boolean getActive() {
		return active;
	}
	public void setActive(Boolean active) {
		this.active = active;
	}
	public Date getDateOfLaunch() {
		return dateOfLaunch;
	}
	public void setDateOfLaunch(Date dateOfLaunch) {
		this.dateOfLaunch = dateOfLaunch;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public Boolean getHasTeaser() {
		return hasTeaser;
	}
	public void setHasTeaser(Boolean hasTeaser) {
		this.hasTeaser = hasTeaser;
	}
	@Override
	public String toString() {
		return String.format("%20s\t%10d\t%b\t%10s\t%15s\t%b", title, boxOffice, active, DateUtil.converToString(dateOfLaunch), genre, hasTeaser);
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}
	
	
}
