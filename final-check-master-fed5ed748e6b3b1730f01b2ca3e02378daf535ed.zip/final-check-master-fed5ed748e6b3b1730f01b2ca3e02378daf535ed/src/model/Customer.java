package model;

import java.util.ArrayList;

public class Customer extends User{

	private ArrayList<Movie> favourites;
	
	public Customer() {
		super();
	}

	public Customer(String userName, String password) {
		super(userName,password);
		this.favourites = new ArrayList<>();
	}

	public ArrayList<Movie> getFavourites() {
		return favourites;
	}

	public void setFavourites(ArrayList<Movie> favourites) {
		this.favourites = favourites;
	}
}
