package dao;

import model.User;

public interface Authenticator {
	public User authenticate(String userName, String password);
}
