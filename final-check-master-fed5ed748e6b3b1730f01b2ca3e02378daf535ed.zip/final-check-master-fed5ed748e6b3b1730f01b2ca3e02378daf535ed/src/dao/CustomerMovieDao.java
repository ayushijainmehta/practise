package dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import model.Customer;
import model.Movie;

public class CustomerMovieDao {
	private static List<Movie> moviesList;
	private static List<Customer> customerList;
	public CustomerMovieDao() {
		if(moviesList == null) {
			moviesList = MoviesListSingleton.getMoviesList();
		}
		if(customerList == null) {
			customerList = new CustomerAuthenticator().getCustomerList();
		}
	}
	public List<Movie> getAllMovies() {
		List<Movie> filteredMovieList = new ArrayList<>();
		for(Movie movie: moviesList) {
			if(movie.getDateOfLaunch().before(new Date()) && movie.getActive()) {
				filteredMovieList.add(movie);
			}
		}
		return filteredMovieList;
	}
	public Movie getMovie(String title) {
		List<Movie> filteredMovieList = new ArrayList<>();
		for(Movie movie: moviesList) {
			if(movie.getDateOfLaunch().before(new Date()) && movie.getActive()) {
				filteredMovieList.add(movie);
			}
		}
		for(Movie movie: filteredMovieList) {
			if(movie.getTitle().equals(title)){
				return movie;
			}
		}
		return null;
	}
	public List<Movie> getAllFavourites(String userName) {
		Customer currentCustomer = getCustomer(userName);
		if(currentCustomer != null) {
			return currentCustomer.getFavourites();
		}
		else {
			System.out.println("Could not find customer of this username");
			return null;
		}
		
	}
	public void addToFavourites(String username,Movie movie) {
		Customer currentCustomer = getCustomer(username);
		if(currentCustomer != null){
			if(!currentCustomer.getFavourites().contains(movie)){
				currentCustomer.getFavourites().add(movie);		
				System.out.println("Movie added to favourites");
			} else {
				System.out.println("Movie already in favourites");
			}
		}
		else {
			System.out.println("Could not find customer");
			return;
		}
		
	}
	public boolean removeFromFavourites(String username, String title) {
		Customer currentCustomer = getCustomer(username);
		if(currentCustomer != null) {
			
			List<Movie> list = currentCustomer.getFavourites();
			Movie movieToDelete = getMovie(title);
			if(list.contains(movieToDelete)) {
				list.remove(movieToDelete);
				return true;
			}
			else {
				return false;
			}
		}
		else {
			System.out.println("Could not find customer");
			return false;
		}
	}
	public Customer getCustomer(String userName) {
		for(Customer customer: customerList) {
			if(customer.getUserName().equals(userName))
				return customer;
		}
		return null;
	}
	
}
