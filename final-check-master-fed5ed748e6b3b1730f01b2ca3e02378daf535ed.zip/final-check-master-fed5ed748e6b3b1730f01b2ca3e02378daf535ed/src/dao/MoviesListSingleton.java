package dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import model.Movie;
import util.DateUtil;

public class MoviesListSingleton {
	private static List<Movie> moviesList;
	private MoviesListSingleton() {
		if(moviesList == null) {
			moviesList = new ArrayList<>();
			try {
				moviesList.add(new Movie("Avatar", 2787965087l, true, DateUtil.convertToDate("15/03/2017"),"Science Fiction", true ));
				moviesList.add(new Movie("Avengers", 1518812988l, true, DateUtil.convertToDate("23/12/2017"),"Superhero", false ));
				moviesList.add(new Movie("Titanic", 2187463944l, true, DateUtil.convertToDate("21/08/2017"),"Romance", false ));
				moviesList.add(new Movie("Jurassic World", 1671713208l, false, DateUtil.convertToDate("02/07/2017"),"Science Fiction", true ));
				moviesList.add(new Movie("Avengers: End Game", 2750760348l,true, DateUtil.convertToDate("02/11/2022"),"Superhero", true ));
			} catch(ParseException e) {
				e.printStackTrace();
			}
		}
	}
	public static List<Movie> getMoviesList() {
		
		if(moviesList == null) {
			new MoviesListSingleton();
			return moviesList;
		}
		else
			return moviesList;
	}

}
