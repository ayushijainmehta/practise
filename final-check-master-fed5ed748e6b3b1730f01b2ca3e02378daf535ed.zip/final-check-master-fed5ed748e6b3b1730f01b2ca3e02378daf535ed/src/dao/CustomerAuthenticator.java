package dao;

import java.util.ArrayList;
import java.util.List;

import model.Customer;

public class CustomerAuthenticator implements Authenticator {
	private static ArrayList<Customer> customerList;
	public CustomerAuthenticator() {
		if(customerList == null ) {
			customerList = new ArrayList<>();
			customerList.add(new Customer("user1","12345"));
			customerList.add(new Customer("user2","678910"));
			customerList.add(new Customer("user3","111213"));
			customerList.add(new Customer("user4","141516"));
			customerList.add(new Customer("user5","171819"));			
		}
	}
	@Override
	public Customer authenticate(String userName,String password) {
		for(Customer customer: customerList) {
			if(customer.getUserName().equals(userName) && customer.getPassword().equals(password)){
				return customer;
			}
		}
		return null;
	}
	public List<Customer> getCustomerList() {
		return customerList;
	}
}
