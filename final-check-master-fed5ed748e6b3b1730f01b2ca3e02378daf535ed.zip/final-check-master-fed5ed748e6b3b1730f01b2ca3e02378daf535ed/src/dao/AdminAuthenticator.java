package dao;

import java.util.ArrayList;

import model.User;

public class AdminAuthenticator implements Authenticator{
	private ArrayList<User> adminList;
	public AdminAuthenticator() {
		adminList = new ArrayList<>();
		adminList.add(new User("user1","12345"));
		adminList.add(new User("user2","678910"));
		adminList.add(new User("user3","111213"));
		adminList.add(new User("user4","141516"));
		adminList.add(new User("user5","171819"));
	}
	@Override
	public User authenticate(String userName,String password) {
		for(User user: adminList) {
			if(user.getUserName().equals(userName) && user.getPassword().equals(password)){
				return user;
			}
		}
		return null;
	}
}
