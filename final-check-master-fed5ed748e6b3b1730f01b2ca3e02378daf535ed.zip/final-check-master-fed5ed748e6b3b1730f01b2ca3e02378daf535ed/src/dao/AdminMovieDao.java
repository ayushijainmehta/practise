package dao;

import java.util.List;

import model.Movie;

public class AdminMovieDao {
	private static List<Movie> moviesList;
	
	public AdminMovieDao() {
		if(moviesList == null) {
			moviesList = MoviesListSingleton.getMoviesList();
		}
	}
	public List<Movie> getMoviesList() {
		return moviesList;
	}
	public void addMovie(Movie movie) {
		moviesList.add(movie);
	}
	public boolean removeMovie(String title) {
		Movie movieToRemove = getMovie(title);
		if(movieToRemove != null) {
			moviesList.remove(movieToRemove);
			return true;
		}
		else
			return false;
	}
	public void updateMovie(String title,Movie movie) {
		Movie currentMovie = getMovie(title);
		if(currentMovie != null) {
			currentMovie.setActive(movie.getActive());
			currentMovie.setBoxOffice(movie.getBoxOffice());
			currentMovie.setDateOfLaunch(movie.getDateOfLaunch());
			currentMovie.setGenre(movie.getGenre());
			currentMovie.setHasTeaser(movie.getHasTeaser());
			currentMovie.setTitle(movie.getTitle());
		}
	}
	public Movie getMovie(String title) {
		for(Movie movie: moviesList) {
			if(movie.getTitle().equals(title))
				return movie;
		}
		return null;
	}
}
