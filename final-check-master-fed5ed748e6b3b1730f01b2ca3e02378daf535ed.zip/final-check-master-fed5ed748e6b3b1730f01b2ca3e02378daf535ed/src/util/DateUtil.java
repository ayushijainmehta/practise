package util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	private static final SimpleDateFormat FORMAT = new SimpleDateFormat("dd/mm/yyyy");
	public static Date convertToDate(String date) throws ParseException {
		Date newDate = FORMAT.parse(date);
		return newDate;
	}
	public static String converToString(Date date) {
		return FORMAT.format(date);
	}
}

