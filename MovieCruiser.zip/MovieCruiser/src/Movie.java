public class Movie {
	protected int id;
    protected String title;
    protected String boxOffice;
    protected String dateOfLaunch;
    protected String active;
    protected String genre;
    protected String hasTeaser;
    protected int getId() {
		return id;
	}

	protected void setId(int id) {
		this.id = id;
	}

	protected String getTitle() {
		return title;
	}

	protected void setTitle(String title) {
		this.title = title;
	}

	protected String getBoxOffice() {
		return boxOffice;
	}

	protected void setBoxOffice(String boxOffice) {
		this.boxOffice = boxOffice;
	}

	protected String getDateOfLaunch() {
		return dateOfLaunch;
	}

	protected void setDateOfLaunch(String dateOfLaunch) {
		this.dateOfLaunch = dateOfLaunch;
	}

	protected String getActive() {
		return active;
	}

	protected void setActive(String active) {
		this.active = active;
	}

	protected String getGenre() {
		return genre;
	}

	protected void setGenre(String genre) {
		this.genre = genre;
	}

	protected String getHasTeaser() {
		return hasTeaser;
	}

	protected void setHasTeaser(String hasTeaser) {
		this.hasTeaser = hasTeaser;
	}

	
    
     public Movie() {}

    public Movie(String title, String boxOffice, String dateOfLaunch,String active,String genre,String hasTeaser) {
        super();
        this.title = title;
        this.boxOffice = boxOffice;
        this.dateOfLaunch = dateOfLaunch;
        this.active=active;
        this.genre=genre;
        this.hasTeaser=hasTeaser;
    }

    public Movie(int id,String title, String boxOffice, String dateOfLaunch,String active,String genre,String hasTeaser) {
        super();
        this.id = id;
        this.title = title;
        this.boxOffice = boxOffice;
        this.dateOfLaunch = dateOfLaunch;
        this.active=active;
        this.genre=genre;
        this.hasTeaser=hasTeaser;
    }

   
    }
