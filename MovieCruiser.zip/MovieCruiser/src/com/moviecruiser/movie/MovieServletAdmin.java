package com.moviecruiser.movie;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/")
public class MovieServletAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	MovieDAO movieDAO;
	public void init() {
	        movieDAO = new MovieDAO();
	    }
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)
			    throws ServletException, IOException {
			        doGet(request, response);
			    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		String action = request.getServletPath();

        try {
            switch (action) {
               case "/update":
             	System.out.println("welcome to updation pafe");
                updateMovie(request, response);
                break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                default:
                    listUser(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
	
		 
	}
	private void listUser(HttpServletRequest request, HttpServletResponse response)
		    throws SQLException, IOException, ServletException {
		 List < Movie> listMovie = movieDAO.selectAllUsers();
			
	        
	      request.setAttribute("listMovie", listMovie);
		request.getRequestDispatcher("movie-list-admin.jsp").forward(request, response);
		    }
	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
		    throws SQLException, ServletException, IOException {
		    int id = Integer.parseInt(request.getParameter("id"));
	
		     
		       Movie selectedMovie = movieDAO.selectMovie(id);

		       request.setAttribute("movie", selectedMovie);
		      RequestDispatcher dispatcher = request.getRequestDispatcher("edit-movie.jsp");
	    
		      dispatcher.forward(request, response);

		    }
	 private void updateMovie(HttpServletRequest request, HttpServletResponse response)
			    throws SQLException, IOException {
		 System.out.println("Updtaed movie");
			     int id = Integer.parseInt(request.getParameter("id"));
			        String title = request.getParameter("title");
			        String boxOffice= request.getParameter("boxOffice");
			        String active = request.getParameter("active");
			        String dateOfLaunch=request.getParameter("dateOfLaunch");
			        String genre=request.getParameter("genre");
			        String hasTeaser=request.getParameter("hasTeaser");
			       Movie movie=new Movie(id,title,boxOffice,active,dateOfLaunch,genre,hasTeaser);
			      
			    
			        movieDAO.updateMovie(movie);
			       response.sendRedirect("edit-movie-status.jsp");
			    }

	
}