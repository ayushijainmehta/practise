package com.jwt.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class HelloWorldController {

	@RequestMapping({ "/hello" })
	public String secondPage() {
		return "Hello World";
	}
	 @RequestMapping(value="/enter")
	   public String home(Model model) {
	       model.addAttribute("msg",
	                          "a jar packaging example");
	       return "home";
	   }
	 
}
